const configProps = {
  dataPage: 'D_ApplicationList',
  cardMinWidth: '400px'
};
export default configProps;
